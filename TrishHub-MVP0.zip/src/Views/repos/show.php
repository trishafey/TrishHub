<h2>Repository: <?php echo htmlspecialchars($name ?? '', ENT_QUOTES); ?></h2>

<ul>
    <li><a href="/repos/<?php echo htmlspecialchars($name ?? '', ENT_QUOTES); ?>/tree">Browse files</a></li>
    <li><a href="/repos/<?php echo htmlspecialchars($name ?? '', ENT_QUOTES); ?>/commits">View commits</a></li>
</ul>
